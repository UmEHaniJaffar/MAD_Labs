package com.example.jguessgame

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.google.android.material.textfield.TextInputEditText
import kotlin.math.abs
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private val numberToGuess: Int = Random.nextInt(1,1000)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val inputField: TextInputEditText = findViewById(R.id.inputNumber)
        val button: Button = findViewById(R.id.guessButton)

        button.setOnClickListener{

            //Checking if input field is empty
            if(inputField.text.toString().isBlank()){
                showToast("Try Your Luck :)")
            }

            // get guessed number from input field
            val guessedNumber: Int = inputField.text.toString().toInt()

            //Checking Logic

            // if guessed number is equal to number to guess u win
            if(guessedNumber == numberToGuess){
                showToast("You Win!!!")
            }

            else if(guessedNumber < numberToGuess){
                showToast("Guess Higher number")
            }
            else if( guessedNumber > numberToGuess){
                showToast("Guess Lower number")

            }

        }

    }

    private fun showToast(message: String){
        val toast = Toast.makeText(this,message, Toast.LENGTH_SHORT)
        toast.show()
    }

}